#* @get /
#* @serializer fake
function(){
  13
}
